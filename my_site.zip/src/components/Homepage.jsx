

const Homepage = () => {
   
    return (

        < >

            <div className=' flex  justify-center items-center text-center bg-black h-40 font-bold  text-4xl md:text-6xl text-gray-500 mb-1'>
                Welcome To Our Site
            </div>
           


            
        </>
    )
}

export default Homepage