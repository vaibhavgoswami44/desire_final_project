

const About = () => {
    return (

        <>

            <div className="flex flex-wrap m-5 bg-black text-teal-200">

                <details className="p-10 w-64">
                    <summary>About React</summary>
                    <h4 >Es6</h4>
                    <h4>React Rander</h4>
                    <h4>React JSX</h4>
                    <h4>React Components</h4>
                    <h4>React Class</h4>
                    <h4>React Props</h4>
                    <h4>React Events</h4>
                    <h4>React Condation</h4>
                    <h4>React Lists</h4>
                    <h4>React Form</h4>
                    <h4>React Router</h4>
                    <h4>React Memo</h4>

                </details>

                <details className="p-10 w-64">
                    <summary>About JavaScript:</summary>
                    <h4>Promises</h4>
                    <h4>Async/Await</h4>
                    <h4>Fetch</h4>
                    <h4>Classes & Object</h4>
                    <h4>How 'this' Works</h4>
                    <h4>Import/Export</h4>
                    <h4>Events & Events Listners</h4>

                </details>


                <details className="p-10 w-64">

                    <summary>About C Language</summary>
                    <h4>Basics</h4>
                    <h4>Variable Declaration,Definition And Scops </h4>
                    <h4>Datatypes</h4>
                    <h4>Storage Classes</h4>
                    <h4>Operators</h4>
                    <h4>Preprocessor</h4>
                    <h4>Array&string</h4>

                </details>

                <details className="p-10 w-64">
                    <summary>React Hooks:</summary>
                    <h4>useState</h4>
                    <h4>useEffact</h4>
                    <h4>useNevigation</h4>
                    <h4>useLocation</h4>
                    <h4>useContext</h4>
                    <h4>useReducer</h4>
                    <h4>useCallback</h4>
                </details>

                <details className="p-10 w-64">

                    <summary>DateTypes in js</summary>
                    <h4>Boolen Type</h4>
                    <h4>Null Type</h4>
                    <h4>Undefined type</h4>
                    <h4>Number type</h4>
                    <h4>String Type</h4>

                </details>

                <details className="p-10 w-64">

                    <summary>C Function</summary>
                    <h4>C Function</h4>
                    <h4>C Function Parameters</h4>
                    <h4>C Recursion</h4>
                    <h4>C Function Declaration</h4>
                    <h4>c Math Functions</h4>
                </details>

                <details className="p-10 w-64">
                    <summary>Libraries Of js</summary>
                    <h4>jQuery Library</h4>
                    <h4>Reacct Library</h4>
                    <h4>D3.js Library</h4>
                    <h4>Underscore  Library</h4>
                </details>

            </div>

        </>
    )
}

export default About;